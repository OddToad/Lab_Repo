﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SHARP_LAB6_1
{


    class Ellipse
    {
        protected float a;
        protected float b;

        public Ellipse() : this(0, 0) { } // Конструктор по умолчанию
        public Ellipse(float _a, float _b)
        {
            a = _a;
            b = _b;
        }


        public float A
        {
            get { return a; }
            set
            {
                if (value > b && value > 0)
                {
                    a = value;
                }
                else
                {
                    throw new ArgumentException("Ошибка: некорректное значение a.");
                }
            }
        }

        public void Init(float m, float n)
        {
            b = n;
            A = m;
        }


        public float Ellipse_Plosh()
        {
            const double M_PI = 3.14;
            return (float)(M_PI * a * b);
        }

        public static Ellipse Add(Ellipse ellipse1, Ellipse ellipse2)
        {
            Ellipse result = new Ellipse();
            result.Init(ellipse1.a + ellipse2.a, ellipse1.b + ellipse2.b);
            return result;
        }


        public void Read()
        {
            Console.Write("Введите значение a (большая полуось): ");
            float a_val = float.Parse(Console.ReadLine());
            Console.Write("Введите значение b (малая полуось): ");
            float b_val = float.Parse(Console.ReadLine());

            Init(a_val, b_val);
        }

        public void Display()
        {
            Console.WriteLine("Большая полуось (a): " + a);
            Console.WriteLine("Малая полуось (b): " + b);
        }

        internal void Assign(Ellipse ellipse)
        {
            a = ellipse.a; 
            b = ellipse.b;
        }
    }



}
