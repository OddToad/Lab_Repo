﻿namespace SHARP_LAB6_1
{
    class Program
    {
        static void Main()
        {
            try
            {
                Ellipse c = new Ellipse();
                Ellipse c2 = new Ellipse();
                Ellipse c3 = new Ellipse();
                Ellipse c1 = new Ellipse();

                Console.WriteLine("Введите параметры для эллипса 1: ");
                c1.Read();

                Console.WriteLine("Введите параметры для эллипса 2: ");
                c2.Read();

                c3 = Ellipse.Add(c2, c1);

                Console.WriteLine("Сумма эллипсов 1 и 2: ");
                c3.Display();

                // Создаем объекты базового и производного классов
                Ellipse c0 = new Ellipse();
                Ellipse3D ellipse3D = new Ellipse3D(45, 5, 7);

                // Инициализируем объект базового класса
                c0.Init(23, 2);

                // Присваиваем объекту производного класса объект базового класса
                ellipse3D.Assign(c0);

                // Выводим информацию о пространственном эллипсе
                ellipse3D.Display();

                // Демонстрируем работу с методами Get и Put для поля z
                Console.WriteLine($"Значение поля z: {ellipse3D.Get()}");
                ellipse3D.Put(85);
                Console.WriteLine($"Новое значение поля z: {ellipse3D.Get()}");

            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
                Environment.Exit(1);
            }
        }
    }
}

