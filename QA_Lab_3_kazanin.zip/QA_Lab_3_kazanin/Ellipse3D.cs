﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SHARP_LAB6_1
{
    // Новый производный класс Ellipse3D
    class Ellipse3D : Ellipse
    {
        private float z;

        public Ellipse3D() : this(0, 0, 0) { } // Конструктор по умолчанию

        // e. Конструктор с параметрами, вызывающий конструктор базового класса
        // Конструктор класса Cylinder с параметрами, вызывающий конструктор базового класса
        public Ellipse3D(float _a, float _b, float _z) : base(_a, _b)
        {
            Init(_a, _b);
            z = _z;
        }

        public void Put(float _z)
        {
            z = _z;
        }

        public double Get()
        {
            return z;
        }


        // Перегрузка функции Init для добавления поля z
        public new void Init(float m, float n, float _z)
        {
            base.Init(m, n);
            z = _z;
        }

        // Перегрузка функции Ellipse_Plosh для учета поля z
        public new float Ellipse_Plosh()
        {
            const double M_PI = 3.14;
            return (float)(M_PI * a * b * z);
        }

        // Перегрузка функции Display для вывода информации о поле z
        public new void Display()
        {
            base.Display();
            Console.WriteLine("Расстояние между плоскостями (z): " + z);
        }

        // Перегрузка функции Read для ввода значения z
        public new void Read()
        {
            base.Read();
            Console.Write("Введите значение z (расстояние между плоскостями): ");
            z = float.Parse(Console.ReadLine());
        }

        public void Assign(Ellipse ellipse)
        {
            base.Assign(ellipse);
            z = (a+b) / 2; // присваиваем половину малой полуоси базового класса
        }

    }
}
